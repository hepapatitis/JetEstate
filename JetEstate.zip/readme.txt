       __     __  ______     __        __     
      / /__  / /_/ ____/____/ /_____ _/ /____ 
 __  / / _ \/ __/ __/ / ___/ __/ __ `/ __/ _ \
/ /_/ /  __/ /_/ /___(__  ) /_/ /_/ / /_/  __/
\____/\___/\__/_____/____/\__/\__,_/\__/\___/ 
                                              

.=========================================================.
|                                                         |
|                          HELLO                          |
|                                                         |
'========================================================='

Thank you very very very much for buying this template. Tons of appreciation for you who bought it.

If you have any question or feedback regarding the template, please email me at support@memoriesdust.com.



.=========================================================.
|                                                         |
|                           FAQ                           |
|                                                         |
'========================================================='

Q:	How to trigger fade animation when content is in view?
A:	In order to trigger the animation, you have to add the following attribute to the element
	data-animation="{animation}"
	and make sure animate.css file is always loaded.
	
	It should look like this:
	
	<div data-animation="bounce">
		...
	</div>

	For a full list of animation, check out Animate.css Website (http://daneden.github.io/animate.css/)


.=========================================================.
|                                                         |
|                         CREDITS                         |
|                                                         |
'========================================================='

USED PHOTOS
==================================
All Stock Photos belong to http://deathtothestockphoto.com


USED FONT
==================================
- Lato - http://www.google.com/fonts/specimen/Lato
- Font Awesome - http://fortawesome.github.io/Font-Awesome/
- Glyphicons - http://glyphicons.com/


USED SCRIPTS
==================================
- Twitter Bootstrap 3.1.0 - http://getbootstrap.com/
- jQuery v1.10.1 - http://jquery.com
- jQuery InView - http://remysharp.com/2009/01/26/element-in-view-event-plugin/
- Animate.css - http://daneden.github.io/animate.css/
- Modernizr 2 - http://modernizr.com/news/modernizr-2/
- HTML5 Shiv - https://github.com/aFarkas/html5shiv
- Respond.js - http://responsejs.com
